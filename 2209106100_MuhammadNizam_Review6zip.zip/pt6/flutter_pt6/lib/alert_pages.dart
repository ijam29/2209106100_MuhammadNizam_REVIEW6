import 'package:flutter/material.dart';

class DialogPage extends StatelessWidget {
  const DialogPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Nama Kalian"),
      ),
      body: Center(
        child: ElevatedButton(
          onPressed: () {},
          child: Text("Tampilkan Alert Dialog"),
        ),
      ),
    );
  }
}
